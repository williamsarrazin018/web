<?php
namespace Crud\Error\Exception;

class MissingListenerException extends CrudException
{
}
