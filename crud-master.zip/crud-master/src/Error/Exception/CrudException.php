<?php
namespace Crud\Error\Exception;

class CrudException extends \Exception
{
}
