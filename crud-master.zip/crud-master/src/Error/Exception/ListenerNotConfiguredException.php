<?php
namespace Crud\Error\Exception;

class ListenerNotConfiguredException extends CrudException
{
}
