<?php
namespace Crud\Error\Exception;

class ActionNotConfiguredException extends CrudException
{
}
