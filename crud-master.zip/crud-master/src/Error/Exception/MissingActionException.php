<?php
namespace Crud\Error\Exception;

class MissingActionException extends CrudException
{
}
